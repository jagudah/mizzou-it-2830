const express = require('express');
const http = require('http');
const app = express();
const hostname = 'localhost';
const port = 3000;

app.use(express.static('public'));

const server = http.createServer((req, res) => {
    res.statusCode = 404;
});

app.get('/', function(req, res) {
    res.sendFile('C:/Users/udohe/code/week12/public/index.html');
});

server.listen(port, hostname, () => {
    console.log('Server running at http://',hostname,':',port);
});

app.listen(port, () => {
    console.log('App listening on port',port)
});