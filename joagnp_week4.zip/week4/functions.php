<?php

function deal_main()
{
    $card = rand(1,10);

    return $card;
}

function deal_side()
{
    $card = rand(-5,5);

    return $card;
}

function p1Hit(){

    $bet1 = $_POST['bet1'];
    echo "<h3>Player 1 Hit</h3>";
    echo "<h4>Bet: $".$bet1."</h4>";

}

function p1Stand(){

    echo "<h3>Player 1 Stand</h3>";

}

function p2Hit(){

    $bet2 = $_POST['bet2'];
    echo "<h3>Player 2 Hit</h3>";
    echo "<h4>Bet: $".$bet2."</h4>";

}

function p2Stand(){

    echo "<h3>Player 2 Stand</h3>";

}

function resetGame(){
    
    echo "<h3>Reset</h3>";

}
?>