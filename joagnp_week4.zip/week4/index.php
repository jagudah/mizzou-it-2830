<?php
    require 'functions.php'
?>

<html>
    <head>
        <title>Blackjack Card Game</title>
    </head>
    <body>
        <h1>Justin Agudah</h1>
        <?php
        date_default_timezone_set('America/Chicago');
        echo '<h2>'.date('l, m/d/Y, h:i:s A').'</h2>';
        ?>
        <table>
            <tr>
                <th>Player 1 Main Deck</th>
                <th>Player 1 Side Deck</th>
                <th>Player 2 Main Deck</th>
                <th>Player 2 Side Deck</th>
            </tr>
            <tr>
                <td><?= deal_main(); ?></td>
                <td><?= deal_side().",".deal_side().",".deal_side(); ?></td>
                <td><?= deal_main(); ?></td>
                <td><?= deal_side().",".deal_side().",".deal_side(); ?></td>
            </tr>
        </table>

        <?php
            if (isset($_POST['hit1'])){
                p1Hit();
            }

            elseif (isset($_POST['stand1'])){
                p1Stand();
            }

            elseif (isset($_POST['hit2'])){
                p2Hit();
            }

            elseif (isset($_POST['stand2'])){
                p2Stand();
            }

            elseif (isset($_POST['reset'])){
                resetGame();
            }
        ?>

        <form method="post" id="p1" action="<?php echo $_SERVER['PHP_SELF'];?>">
            <br><label for="player1">Player 1</label><br>
            <label for="bet1">Bet: </label>
            <input type="text" id="bet1" name="bet1" value="0"><br>
            <input type="submit" id="hit1" name="hit1" value="Hit" onclick="p1Hit()"><br>
            <input type="submit" id="stand1" name="stand1" value="Stand" onclick="p1Stand()"><br>
        </form>

        <form method="post" id="p2" action="<?php echo $_SERVER['PHP_SELF'];?>">
            <label for="player2">Player 2</label><br>
            <label for="bet2">Bet: </label>
            <input type="text" id="bet2" name="bet2" value="0"><br>
            <input type="submit" id="hit2" name="hit2" value="Hit" onclick="p2Hit()"><br>
            <input type="submit" id="stand2" name="stand2" value="Stand" onclick="p2Stand()"><br>
        </form>

        <form method="post" action="<?php echo $_SERVER['PHP_SELF'];?>">
           <input type="submit" id="reset" name="reset" value="Reset" onclick="resetGame()"> 
        </form>
    </body>
</html>