<?php

function deal_main()
{
    $card = rand(1,10);

    return $card;
}

function deal_side()
{
    $card = rand(-5,5);

    return $card;
}
?>