<?php
    require 'functions.php'
?>

<html>
    <head>
        <title>Blackjack Card Game</title>
    </head>
    <body>
        <h1>Justin Agudah</h1>
        <table>
            <tr>
                <th>Player 1 Main Deck</th>
                <th>Player 1 Side Deck</th>
                <th>Player 2 Main Deck</th>
                <th>Player 2 Side Deck</th>
            </tr>
            <tr>
                <td><?= deal_main(); ?></td>
                <td><?= deal_side().",".deal_side().",".deal_side(); ?></td>
                <td><?= deal_main(); ?></td>
                <td><?= deal_side().",".deal_side().",".deal_side(); ?></td>
            </tr>
        </table>
    </body>
</html>