<?php
    session_start();
    $error = '';

    if($_SERVER['REQUEST_METHOD'] === 'POST')
    {
        $con = mysqli_connect("172.20.0.2","dbuser","dbpass","db");
        $loginInfo = mysqli_query($con, "SELECT * FROM user WHERE username='". $_POST["username"] . 
        "' and password='". $_POST["password"]."'");
        $row = mysqli_fetch_array($loginInfo);

        if(is_array($row))
        {
            $_SESSION['user_id'] = $row['id'];
            $_SESSION['username'] = $row['username'];
        }
        else
        {
            $error = 'Incorrect username or password';
        }
    }
    if(isset($_SESSION['user_id']))
    {
        header('Location:index.php');
    }
?>

<html>
    <head>
        <title>User Login</title>
    </head>
    <body>
        <h1>Justin Agudah</h1>
        <form name='loginForm' method='post' action="<?php echo $_SERVER['PHP_SELF']; ?>">
            <div class='error'><?php if(!empty($error)) { echo $error; } ?></div>
            <h3>Welcome, please log in</h3>
            <label for='username'>Username</label>
            <input type='text' name='username'><br>
            <label for='password'>Password</label>
            <input type='password' name='password'><br>
            <input type='submit' name='login' value='login'>
        </form>
    </body>
</html>