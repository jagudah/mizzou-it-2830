<?php
    session_start();
    if(!isset($_SESSION['username']))
    {
        header("Location:login.php");
    }
?>
<html>
    <head>
        <title>User Login</title>
    </head>
    <style>
        table, th, td   {
            border: 1px solid black;
            border-collapse: collapse;
        }
    </style>
    <body>
        <h1>Justin Agudah</h1>
        <?php if(isset($_SESSION['username'])): ?>
            <h2>Welcome <?= $_SESSION['username'] ?>. Click here to <a href="logout.php" 
                tite="Logout">Logout</a></h2>
        <?php
            date_default_timezone_set('America/Chicago');
            echo '<h3>'.date('l, m/d/Y, h:i:s A').'</h3>';

            $con = mysqli_connect("172.20.0.2","dbuser","dbpass","db");

            if(mysqli_connect_errno()){
                echo "Failed to connect to MySQL: " . mysqli_connect_error();
                exit();
            }

            $result = mysqli_query($con, "SELECT * FROM person");
        ?>

        <table>
            <tr>
                <th>ID</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Hometown</th>
            </tr>
            <?php foreach($result as $row): ?>
            <tr>
                <td><?= $row['id'] ?></td>
                <td><?= $row['fname'] ?></td>
                <td><?= $row['lname'] ?></td>
                <td><?= $row['hometown'] ?></td>
            </tr>
            <?php endforeach; ?>
        </table>
        <?php endif; ?>
    </body>
</html>