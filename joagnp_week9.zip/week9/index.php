<?php
    session_start();
    if(!isset($_SESSION['username']))
    {
        header("Location:login.php");
    }
?>
<html>
    <head>
        <title>User Login</title>
    </head>
    <style>
        table, th, td   {
            border: 1px solid black;
            border-collapse: collapse;
        }
        th  {
            color: red;
        }
    </style>
    <body>
        <h1>Justin Agudah</h1>
        <?php if(isset($_SESSION['username'])): ?>
            <h2>Welcome <?= $_SESSION['username'] ?>. Click here to <a href="logout.php" 
                tite="Logout">Logout</a></h2>
        <?php
            date_default_timezone_set('America/Chicago');
            echo '<h3>'.date('l, m/d/Y, h:i:s A').'</h3>';

            $con = mysqli_connect("172.20.0.2","dbuser","dbpass","db");

            if(mysqli_connect_errno()){
                echo "Failed to connect to MySQL: " . mysqli_connect_error();
                exit();
            }

            $result = mysqli_query($con, "SELECT * FROM calendar"); 
        ?>

        <table>
            <tr>
                <th>ID</th>
                <th>Title</th>
                <th>Description</th>
                <th>Date</th>
            </tr>
            <?php foreach($result as $row): ?>
            <?php if($_SESSION['user_id'] == $row['user_id']): ?>
            <tr>
                <td><?= $row['id'] ?></td>
                <td><?= $row['title'] ?></td>
                <td><?= $row['description'] ?></td>
                <td><?= $row['date'] ?></td>
            </tr>
            <?php endif; ?>
            <?php endforeach; ?>
        </table>
        <?php endif; ?>
    </body>
</html>