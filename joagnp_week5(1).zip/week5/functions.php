<?php

function deal_main($player)
{
    $card = rand(1,10);
    $_SESSION[$player]['main'][] = $card;
    $_SESSION[$player]['main']['sum'][] = $card;
    
}

function deal_side($player)
{
    for($x = 0; $x < 3; $x++){
        $card = rand(-5,5);
        $_SESSION[$player]['side'][$x] = $card;
    }
}

?>