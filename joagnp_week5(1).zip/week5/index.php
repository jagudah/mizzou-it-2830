<?php
    session_start();
    //print_r($_SESSION);
    require 'functions.php';
?>

<html>
    <head>
        <title>Blackjack Card Game</title>
        <style>
        table, th, td   {
        border: 1px solid black;
        border-collpase: collapse;
        }
        </style>
    </head>
    <body>
        <h1>Justin Agudah</h1>
        <?php
        date_default_timezone_set('America/Chicago');
        echo '<h2>'.date('l, m/d/Y, h:i:s A').'</h2>';
        print_r($_COOKIE);
        ?>

        <?php if(!(empty($_SESSION['begin']))): ?>

        <?php
        if (empty($_SESSION['p1']))
        {
            $_SESSION['p1'] = [];
        }
        if (empty($_SESSION['p2']))
        {
            $_SESSION['p2'] = [];
        }
        if (empty($_SESSION['p1']['bet1']))
        {
            $_SESSION['p1']['bet1'] = '';
        }
        if (empty($_SESSION['begin']))
        {
            $_SESSION['begin'] = 0;
        }
        if (empty($_SESSION['reset']))
        {
            $_SESSION['reset'] = 0;
        }
        if (empty($_SESSION['p1']['main']['sum']))
        {
            $_SESSION['p1']['main']['sum'] = [];
        }
        if (empty($_SESSION['p2']['main']['sum']))
        {
            $_SESSION['p2']['main']['sum'] = [];
        }
        if (empty($_SESSION['p2']['bet1']))
        {
            $_SESSION['p2']['bet1'] = '';
        }
        
        print_r($_SESSION);
        deal_main('p1');
        deal_side('p1');
        deal_side('p1');
        deal_side('p1');
        deal_main('p2');
        deal_side('p2');
        deal_side('p2');
        deal_side('p2');
        ?>

        <table>
            <tr>
                <th>Player 1 Main Deck</th>
                <th>Player 1 Side Deck</th>
                <th>Player 2 Main Deck</th>
                <th>Player 2 Side Deck</th>
            </tr>
            <tr>
                <td><?= $_SESSION['p1']['main'][0]. "<br> Total:".array_sum($_SESSION['p1']['main']['sum']); ?></td>
                
                <td>
                    <?php for($num = 0; $num <= 2; $num++): ?>
                    <form method="post">
                        <input type="button" id="side1" name="side1" value="<?= $_SESSION['p1']['side'][$num];?>">
                    </form>
                    <?php endfor; ?>
                </td>
                <td><?= $_SESSION['p2']['main'][0]. "<br> Total:".array_sum($_SESSION['p2']['main']['sum']); ?></td>
                <td>
                    <?php for($num = 0; $num <= 2; $num++): ?>
                    <form method="post">
                        <input type="button" id="side2" name="side2" value="<?= $_SESSION['p2']['side'][$num];?>">
                    </form>
                    <?php endfor; ?>
                </td>
            </tr>
        </table>

        <?php
            if (!(empty($_SESSION['reset']))){
                session_unset();
                session_destroy();
            }
            elseif (isset($_POST['hit1'])){
                $bet1 = $_POST['bet1'];
                if (empty($_SESSION['p1']['bet1']))
                {
                    $_SESSION['p1']['bet1'] = $bet1;
                }
                echo "<h3>Player 1 Hit</h3>";
                echo "<h4>Bet: $".$bet1."</h4>";
                deal_main('p1');
                if (array_sum($_SESSION['p1']['main']['sum']) > 21)
                {
                    echo "<h3>Player 1 lost $".$_SESSION['p1']['bet1']."</h3><br>";
                    echo "<h3>Player 2 won $".$_SESSION['p2']['bet1']."</h3><br>";
                }
            }

            elseif (isset($_POST['stand1'])){
                echo "<h3>Player 1 Stand</h3>";
            }

            elseif (isset($_POST['hit2'])){
                $bet2 = $_POST['bet2'];
                if (empty($_SESSION['p2']['bet1']))
                {
                    $_SESSION['p2']['bet1'] = $bet1;
                }
                echo "<h3>Player 2 Hit</h3>";
                echo "<h4>Bet: $".$bet2."</h4>";
                deal_main('p2');
                if (array_sum($_SESSION['p2']['main']['sum']) > 21)
                {
                    echo "<h3>Player 2 lost $".$_SESSION['p2']['bet1']."</h3><br>";
                    echo "<h3>Player 1 won $".$_SESSION['p1']['bet1']."</h3><br>";
                }
            }

            elseif (isset($_POST['stand2'])){
                echo "<h3>Player 2 Stand</h3>";
            }
        ?>

        <form method="post" id="p1" action="<?php echo $_SERVER['PHP_SELF'];?>">
            <br><label for="player1">Player 1</label><br>
            <label for="bet1">Bet: </label>
            <input type="text" id="bet1" name="bet1" value="">
            <?php if (array_sum($_SESSION['p1']['main']['sum']) < 21): ?>
            <input type="submit" id="hit1" name="hit1" value="Hit">
            <?php endif; ?>
            <input type="submit" id="stand1" name="stand1" value="Stand"><br>
        </form>

        <form method="post" id="p2" action="<?php echo $_SERVER['PHP_SELF'];?>">
            <label for="player2">Player 2</label><br>
            <label for="bet2">Bet: </label>
            <input type="text" id="bet2" name="bet2" value="">
            <?php if (array_sum($_SESSION['p2']['main']['sum']) < 21): ?>
            <input type="submit" id="hit2" name="hit2" value="Hit">
            <?php endif; ?>
            <input type="submit" id="stand2" name="stand2" value="Stand"><br>
           
        </form>

        <form method="post" action="<?php echo $_SERVER['PHP_SELF'];?>">
           <input type="submit" id="reset" name="reset" value="Reset" onclick="<?php $SESSION['reset'] = 1?>"> 
        </form> 
        <?php else: ?>
            <form method="post" action="<?php echo $_SERVER['PHP_SELF'];?>">
                <input type="submit" id="begin" name="begin" value="Begin" onclick="<?php $_SESSION['begin'] = 1?>">
            </form>
        <?php endif; ?>
    </body>
</html>